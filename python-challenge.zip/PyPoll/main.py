import csv

# Path to CSV file
input_csv_path = "/Users/ZAC/Desktop/Class Local/Homework/Challenge 3/python-challenge/PyPoll/Resources/election_data.csv"

# Path to the output txt file
output_txt_path = "/Users/ZAC/Desktop/Class Local/Homework/Challenge 3/python-challenge/PyPoll/output.txt"

# Set variables
total_votes = 0
candidate_votes = {}
winner = ""
winner_votes = 0

# Read CSV file
with open(input_csv_path, "r") as csvfile:
    csvreader = csv.reader(csvfile)
    next(csvreader)  # Skip header
    
    # Count votes and store in dictionary
    for row in csvreader:
        total_votes += 1
        candidate = row[2]
        candidate_votes[candidate] = candidate_votes.get(candidate, 0) + 1

        # Update winner information
        if candidate_votes[candidate] > winner_votes:
            winner = candidate
            winner_votes = candidate_votes[candidate]

# Calculate percentages
candidate_percentages = {candidate: (votes / total_votes) * 100 for candidate, votes in candidate_votes.items()}

# Print results
print("Election Results")
print("-------------------------")
print(f"Total Votes: {total_votes}")
print("-------------------------")
for candidate, votes in candidate_votes.items():
    print(f"{candidate}: {candidate_percentages[candidate]:.3f}% ({votes})")
print("-------------------------")
print(f"Winner: {winner}")
print("-------------------------")

# Export results to txt file
with open(output_txt_path, "w") as output_file:
    output_file.write("Election Results\n")
    output_file.write("-------------------------\n")
    output_file.write(f"Total Votes: {total_votes}\n")
    output_file.write("-------------------------\n")
    for candidate, votes in candidate_votes.items():
        output_file.write(f"{candidate}: {candidate_percentages[candidate]:.3f}% ({votes})\n")
    output_file.write("-------------------------\n")
    output_file.write(f"Winner: {winner}\n")
    output_file.write("-------------------------\n")