import csv

# Set file paths
input_csv_path = "/Users/ZAC/Desktop/Class Local/Homework/Challenge 3/python-challenge/PyBank/Resources/budget_data.csv"
output_txt_path = "/Users/ZAC/Desktop/Class Local/Homework/Challenge 3/python-challenge/PyBank/output.txt"

# open and read csv file
with open(input_csv_path, "r") as csvfile:
    csvreader = csv.reader(csvfile, delimiter=",")
    csv_header = next(csvreader)  # Skip the header row

    # Set variables
    row_count = 0
    total_sum = 0
    max_profit = float('-inf')  # Initialize with negative infinity
    min_profit = float('inf')   # Initialize with positive infinity
    max_profit_date = ""
    min_profit_date = ""

    # Loop through each row 
    for row in csvreader:
        # Increment row count
        row_count += 1

        # Check if row has at least 2 columns
        if len(row) >= 2:
            # Extract date and profit/loss value
            date = row[0]
            profit = float(row[1])

            # Update total profit/loss
            total_sum += profit

            # Update max profit and date
            if profit > max_profit:
                max_profit = profit
                max_profit_date = date

            # Update min profit and date
            if profit < min_profit:
                min_profit = profit
                min_profit_date = date

# Write results to txt file
with open(output_txt_path, "w") as output_file:
    output_file.write("Financial Analysis\n")
    output_file.write("----------------------------------------------------------\n")
    output_file.write(f"Total Months: {row_count}\n")
    output_file.write(f"Total: {total_sum}\n")
    output_file.write(f"Greatest Increase in Profits: ({max_profit_date}): {max_profit}\n")
    output_file.write(f"Greatest Decrease in Profits: ({min_profit_date}): {min_profit}\n")